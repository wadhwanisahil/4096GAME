package keybord;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Keyboard implements KeyListener {
	public static boolean[] keys = new boolean[120];
	public static boolean[] lastKeys = new boolean[120];

	public void update() {
		for (int i = 0; i < keys.length; i++) {
			lastKeys[i] = keys[i];
		}
	}

	public static boolean key(int key) {
		return keys[key];
	}

	public static boolean keyDown(int key) {
		return keys[key] && !lastKeys[key];
	}

	public static boolean keyUp(int key) {
		return !keys[key] && lastKeys[key];
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		keys[e.getKeyCode()] = true;
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		keys[e.getKeyCode()] = false;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}
}
